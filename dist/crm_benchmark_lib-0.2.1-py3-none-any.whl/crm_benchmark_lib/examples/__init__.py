"""
Examples package for CRM Benchmark Library.
""" 